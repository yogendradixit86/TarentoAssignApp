package com.app.controller.rest;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.app.model.Token;
import com.app.service.ITokenService;

@RestController
//@RequestMapping("/api")
public class TokenRestController {

	@Autowired
	private ITokenService service;
	
	@PostMapping("/savetoken")
	public ResponseEntity<String> saveToken(@RequestParam String tokenkey) {
		ResponseEntity<String> response=null;
		Token token=new Token(tokenkey);
		try {
			String tokenId=service.saveToken(token);
			response=new ResponseEntity<String>(tokenId+"-Inserted", HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
			response=new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return response;
	}
	
	@GetMapping("/duplicatecheck/{id}")
	public ResponseEntity<Boolean> validateToken(@PathVariable String id) {
		ResponseEntity<Boolean> response=null;
		boolean exist=service.tokenExist(id);
		if(exist) {			
			response=new ResponseEntity<Boolean>(exist, HttpStatus.OK);
		}else {
			response=new ResponseEntity<>(false,HttpStatus.OK);
		}
		return response;
	}
	
	@GetMapping("/all")
	public ResponseEntity<?> showAllToken() {
		ResponseEntity<?> response=null;
		List<Token> tokens=service.getAllTokens();
		if(tokens!=null && !tokens.isEmpty()) {
			response=new ResponseEntity<List<Token>>(tokens, HttpStatus.OK);
		}else {
			response=new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}
		return response;
	}
	
	@DeleteMapping("/delete/{id}")
	public ResponseEntity<?> deleteToken(@PathVariable String id) {
		ResponseEntity<?> response=null;
		boolean exist=service.tokenExist(id);
		if(exist) {
			service.deleteToken(id);
			response=new ResponseEntity<String>(id+"-Removed", HttpStatus.OK);
		}else {
			response=new ResponseEntity<String>("Token NOT FOUND",HttpStatus.BAD_REQUEST);
		}
		return response;
	}
	
	
	
}
