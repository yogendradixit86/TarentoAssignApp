package com.app.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="tokentbl")
public class Token {

	@Id
	@Column(name="tokenkey")
	private String tokenKey;

		
	public Token() {
		super();
	}

	public Token(String tokenKey) {
		super();
		this.tokenKey = tokenKey;
	}

	public String getTokenKey() {
		return tokenKey;
	}

	public void setTokenKey(String tokenKey) {
		this.tokenKey = tokenKey;
	}

	@Override
	public String toString() {
		return "Token [tokenKey=" + tokenKey + "]";
	}
	
}
