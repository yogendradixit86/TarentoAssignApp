package com.app.service;

import java.util.List;

import com.app.model.Token;

public interface ITokenService {
	public String saveToken(Token token);
	public void deleteToken(String id);
	
	public Token getTokenById(String id);
	public List<Token> getAllTokens();
	public boolean tokenExist(String id);
}
