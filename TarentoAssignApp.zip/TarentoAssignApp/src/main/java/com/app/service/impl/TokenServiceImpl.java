package com.app.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.app.model.Token;
import com.app.repository.IToken;
import com.app.service.ITokenService;

@Service
public class TokenServiceImpl implements ITokenService {
	
	@Autowired
	private IToken repo;

	@Override
	public String saveToken(Token token) {
		return repo.save(token).getTokenKey();
	}

	@Override
	public void deleteToken(String id) {
		repo.deleteById(id);
	}

	@Override
	public Token getTokenById(String id) {
		return repo.findById(id).get();
	}

	@Override
	public List<Token> getAllTokens() {
		return repo.findAll();
	}

	@Override
	public boolean tokenExist(String id) {
		return repo.existsById(id);
	}

}
